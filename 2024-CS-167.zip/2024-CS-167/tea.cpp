#include <iostream>
using namespace std;
main()
	{
		cout <<"                .    .    .                       "<<endl;
		cout <<"                 .    .    .                      "<<endl;
		cout <<"                  .    .    .                     "<<endl;
		cout <<"                 .    .    .                      "<<endl;
		cout <<"                .    .    .                       "<<endl;
		cout <<"                 .    .    .                      "<<endl;
		cout <<"                  .    .    .                     "<<endl;
		cout <<"      .................................           "<<endl;
		cout <<"       `                             `            "<<endl;
		cout <<"        `                           `             "<<endl;
		cout <<"         `                         `              "<<endl;
		cout <<"          `                       `               "<<endl;
		cout <<"           ` ....................`                "<<endl;
		cout <<"      WELCOME   TO   FOODY   APPLICATION          "<<endl;
	}