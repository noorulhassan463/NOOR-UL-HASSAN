#include <iostream>
using namespace std;
main()
	{
		system ("color 17");
		cout << "                  .::---::..          "<<endl;
		cout << "               .-------------.        "<<endl;
		cout << "             .-----------------.      "<<endl;
		cout << "             ----------------:.       "<<endl;
		cout << "            :-----------::.           "<<endl;
		cout << "            -----------:.             "<<endl;
		cout << "            :--------------:..        "<<endl;
		cout << "             :---------------:.       "<<endl;
		cout << "              .--------------:        "<<endl;
		cout << "                .:--------:.          "<<endl;
		
	}