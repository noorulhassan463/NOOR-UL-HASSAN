#include <iostream>
using namespace std;
main ()
	{
		cout <<"  _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _                             "<<endl;
		cout <<"            o     ^__^                                          "<<endl;
		cout <<"             o    (oo)\\______                                  "<<endl;
		cout <<"                  (__)\\      )\\/\\                            "<<endl;
		cout <<"                       ||---w |                                 "<<endl;
		cout <<"                       ||    ||                                 "<<endl;
	}