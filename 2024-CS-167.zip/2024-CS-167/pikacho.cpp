#include <iostream>
using namespace std;
main ()
	{
		system ("color F0");
		cout <<"                 ',_                                     "<<endl;
		cout <<"                  ` `            ___,                    "<<endl;
		cout <<"                   `.`!_......_/'._,,                    "<<endl;
		cout <<"                     !          /      ,                 "<<endl;
		cout <<"                     / o    o   !     , ,_               "<<endl;
		cout <<"                    |)   .      o!  /'    '-             "<<endl;
		cout <<"                     |   -'-            _.'              "<<endl;
		cout <<"                     ;.___    , , ,' '_ <                "<<endl;
		cout <<"                    / ,     / ,;|     > |                "<<endl;
		cout <<"                   (_/     (_/  |,-'  ,-'                "<<endl;
		cout <<"                    !     ,   ,;|,<'                     "<<endl;
		cout <<"                     >    !     ;-'                      "<<endl;
		cout <<"                     (_,-''> _,/                         "<<endl;
		cout <<"                       (_,'                              "<<endl;
	}