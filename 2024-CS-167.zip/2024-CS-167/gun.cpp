#include <iostream>
using namespace std;
main ()
	{
		system ("color 0B");
		cout <<"                                                                         "<<endl;
		cout <<"                   +--^----------,--------,-----,---------^-,            "<<endl;
		cout <<"                    | |||||||||   '--------'     |           o           "<<endl;
		cout <<"                    '+---------------------------^-----------|           "<<endl;
		cout <<"                      ',----------,----------,-------------'             "<<endl;
		cout <<"                        / XXXXXX /'|         /'                          "<<endl;
		cout <<"                       / XXXXXX /  |        /'                           "<<endl;
		cout <<"                      / XXXXXX /'---------'                              "<<endl;
		cout <<"                     / XXXXXX /                                          "<<endl;
		cout <<"                    / XXXXXX /                                           "<<endl;
		cout <<"                   (________(                                            "<<endl;
		cout <<"                    '------'                                             "<<endl;
		cout <<"                                                                         "<<endl;
	}